Survey
    .StylesManager
    .applyTheme("modern");
var json = {
    title: "Tax Saving Investments",
    showProgressBar: "bottom",
    showTimerPanel: "top",
    maxTimeToFinishPage: 10,
    maxTimeToFinish: 25,
    firstPageIsStarted: true,
    startSurveyText: "Start Quiz",
    pages: [
        {
            questions: [
                {
                    type: "html",
                    html: "<h3>Did you know you can save upto 70,000 INR in taxes?</h3> <br/> Take the below trivia to know more. <br/>Please click on <b>'Start Quiz'</b> button when you are ready."
                }
            ]
        }, {
            questions: [
                {
                    type: "radiogroup",
                    name: "civilwar",
                    title: "Which of the below options is not a part of Savings under article 80/C?",
                    choices: [
                        "Public Provident Fund", "Life Insurance Policy", "Employer's Contribution to Provident Fund", "Mutual Funds"
                    ],
                    correctAnswer: "Employer's Contribution to Provident Fund"
                }
            ]
        }, {
            questions: [
                {
                    type: "radiogroup",
                    name: "libertyordeath",
                    title: "What is the Standard Deduction limit as per the Union Budget 2019?",
                    choicesOrder: "random",
                    choices: [
                        "25,000 INR", "30,000 INR", "40,000 INR", "60,000 INR"
                    ],
                    correctAnswer: "40,000 INR"
                }
            ]
        }, {
            maxTimeToFinish: 15,
            questions: [
                {
                    type: "radiogroup",
                    name: "magnacarta",
                    title: "There is no need to file your income tax return if...",
                    choicesOrder: "random",
                    choices: [
                        "TDS has been deducted and all taxes have been duly paid", "Tax-saving investments have reduced your tax to zero.", "Your taxable income is below the basic exemption of Rs 2.5 lakh a year.", 
                        "All of the Above "
                    ],
                    correctAnswer: "Your taxable income is below the basic exemption of Rs 2.5 lakh a year. "
                }
            ]
        }
    ],
    completedHtml: "<h4>You have answered correctly <b>{correctedAnswers}</b> questions from <b>{questionCount}</b>.</h4>"
};
window.survey = new Survey.Model(json);
survey
    .onComplete
    .add(function (result) {
       // document
         //   .querySelector('#surveyResult')
           // .textContent = "Result JSON:\n" + JSON.stringify(result.data, null, 3);
        document.location.href = "/scards/scratchcard.html";
    });
$("#surveyElement").Survey({model: survey});