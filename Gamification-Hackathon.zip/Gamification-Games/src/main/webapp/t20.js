Survey
    .StylesManager
    .applyTheme("modern");
var json = {
    title: "T20 IND vs NZ",
    showProgressBar: "bottom",
    showTimerPanel: "top",
    maxTimeToFinishPage: 10,
    maxTimeToFinish: 25,
    firstPageIsStarted: true,
    startSurveyText: "Start Quiz",
    pages: [
        {
            questions: [
                {
                    type: "html",
                    html: "<h3>Did you know when the next T20 series between IN and NZ?</h3> <br/> Take the below trivia to know more. <br/>Please click on <b>'Start Quiz'</b> button when you are ready."
                }
            ]
        }, {
            questions: [
                {
                    type: "radiogroup",
                    name: "civilwar",
                    title: "Which Indian cricketer scored the highest runs in 4th T20 Match?",
                    choices: [
                        "Rohit Sharma", "Virat Kohli", "Manish Pandey", "Shreyas Ayyer"
                    ],
                    correctAnswer: "Manish Pandey"
                }
            ]
        }, {
            questions: [
                {
                    type: "radiogroup",
                    name: "libertyordeath",
                    title: "who bowled super over in 3rd T20 for India?",
                    choicesOrder: "random",
                    choices: [
                        "Jasprit Bumrah", "Md Shami", "Shardul Thakur", "Y.Chahal"
                    ],
                    correctAnswer: "Jasprit Bumrah"
                }
            ]
        }, {
            maxTimeToFinish: 15,
            questions: [
                {
                    type: "radiogroup",
                    name: "magnacarta",
                    title: "Where do the 5th T20 will be held?",
                    choicesOrder: "random",
                    choices: [
                        "Seddon Park", "Bay Oval", "Eden park", "Basin Reserve"
                    ],
                    correctAnswer: "Bay Oval"
                }
            ]
        }
    ],
    completedHtml: "<h4>You have answered correctly <b>{correctedAnswers}</b> questions from <b>{questionCount}</b>.</h4>"
};
window.survey = new Survey.Model(json);
survey
    .onComplete
    .add(function (result) {
       // document
         //   .querySelector('#surveyResult')
           // .textContent = "Result JSON:\n" + JSON.stringify(result.data, null, 3);
        document.location.href = "/scards/scratchcard.html";
    });
$("#surveyElement").Survey({model: survey});