package com.dbs.gamification;

import android.support.v7.app.AppCompatActivity;
import android.view.Window;

public class CommonUtility {
    public static void disableTitlebar(AppCompatActivity obj){
        obj.requestWindowFeature(Window.FEATURE_NO_TITLE); //will hide the title
        obj.getSupportActionBar().hide(); // hide the title bar
    }
}
