package com.dbs.gamification;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

public class Trivia extends AppCompatActivity {

    private boolean flag = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        CommonUtility.disableTitlebar(this);
        setContentView(R.layout.activity_game);

        String weburl = null;
        int i = (int) (Math.random() * 1000);
        //i=1;
        if(i%3 == 0) {
            weburl = "http://192.168.1.100:8080/quiz.html";

        } else if(i%2 == 0){
            weburl = "http://192.168.1.100:8080/carona.html";

        } else {
            weburl = "http://192.168.1.100:8080/t20.html";

        }
        flag = !flag;
        //String weburl = getIntent().getExtras().get("gameURL").toString();
        System.out.println("activity_game sarat : "+weburl);
        setContentView(R.layout.activity_game);
        WebView webView = (WebView) findViewById(R.id.webview);
        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setDomStorageEnabled(true);
        webSettings.setMediaPlaybackRequiresUserGesture(false);
        webView.loadUrl(weburl);
        webView.setVerticalScrollBarEnabled(true);
        //webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            public boolean shouldOverrideUrlLoading(WebView view, String url) {

                Context context = getApplicationContext();
                CharSequence text = "ssss!"+url;
                int duration = Toast.LENGTH_SHORT;

                Toast toast = Toast.makeText(context, text, duration);
                //toast.show();

                if (url.contains("exit")) {
                    Intent sharingIntent = new Intent(android.content.Intent.ACTION_SEND);
                    sharingIntent.setType("text/plain");
                    String shareBody = "Here is the share content body";
                    sharingIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "Subject Here");
                    sharingIntent.putExtra(android.content.Intent.EXTRA_TEXT, shareBody);
                    startActivity(Intent.createChooser(sharingIntent, "Share via"));
                    return true;
                } else {
                    return false;
                }
            }});
        /* final activity_game obj = this;
        webView.setWebChromeClient(new WebChromeClient() {
            public void onCloseWindow(WebView w){
                super.onCloseWindow(w);
                System.out.println("Window closed");
                Toast.makeText(getApplicationContext(), "window closed", Toast.LENGTH_LONG).show();
                finish();

            }
        });

        if (webView.getUrl().contains("exit")){
            System.out.println("page should not load");
            finish();
        }
        */
    }
}
