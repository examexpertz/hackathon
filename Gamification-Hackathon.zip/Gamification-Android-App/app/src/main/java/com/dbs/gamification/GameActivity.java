package com.dbs.gamification;

import android.content.Context;
import android.content.Intent;
import android.nfc.Tag;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.format.DateUtils;
import android.util.Log;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.File;
import java.util.Date;

public class GameActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        CommonUtility.disableTitlebar(this);
        setContentView(R.layout.activity_game);

        String weburl = "http://192.168.1.100:8080/welcome.html";
        //String weburl = getIntent().getExtras().get("gameURL").toString();
        System.out.println("activity_game sarat : "+weburl);
        setContentView(R.layout.activity_game);
        clearCacheFolder(getBaseContext().getCacheDir(), 7);
        WebView webView = (WebView) findViewById(R.id.webview);
        webView.clearCache(true);
        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setDomStorageEnabled(true);
        webSettings.setMediaPlaybackRequiresUserGesture(false);
        webView.loadUrl(weburl);

        webView.setWebViewClient(new WebViewClient() {
            public boolean shouldOverrideUrlLoading(WebView view, String url) {

                Context context = getApplicationContext();
                CharSequence text = "ssss!"+url;
                int duration = Toast.LENGTH_SHORT;

                Toast toast = Toast.makeText(context, text, duration);
                //toast.show();

                if (url.contains("exit")) {
                    Intent sharingIntent = new Intent(android.content.Intent.ACTION_SEND);
                    sharingIntent.setType("text/plain");
                    String shareBody = "Here is the share content body";
                    sharingIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "Subject Here");
                    sharingIntent.putExtra(android.content.Intent.EXTRA_TEXT, shareBody);
                    startActivity(Intent.createChooser(sharingIntent, "Share via"));
                    return true;
                } else {
                    return false;
                }
            }});

        //webView.setWebChromeClient(new WebChromeClient());
        /* final activity_game obj = this;
        webView.setWebChromeClient(new WebChromeClient() {
            public void onCloseWindow(WebView w){
                super.onCloseWindow(w);
                System.out.println("Window closed");
                Toast.makeText(getApplicationContext(), "window closed", Toast.LENGTH_LONG).show();
                finish();

            }
        });

        if (webView.getUrl().contains("exit")){
            System.out.println("page should not load");
            finish();
        }
        */


    }
    static int clearCacheFolder(final File dir, final int numDays) {

        int deletedFiles = 0;
        if (dir!= null && dir.isDirectory()) {
            try {
                for (File child:dir.listFiles()) {

                    //first delete subdirectories recursively
                    if (child.isDirectory()) {
                        deletedFiles += clearCacheFolder(child, numDays);
                    }

                    //then delete the files and subdirectories in this dir
                    //only empty directories can be deleted, so subdirs have been done first
                    if (child.lastModified() < new Date().getTime() - numDays * DateUtils.DAY_IN_MILLIS) {
                        if (child.delete()) {
                            deletedFiles++;
                        }
                    }
                }
            }
            catch(Exception e) {
            }
        }
        return deletedFiles;
    }
}
