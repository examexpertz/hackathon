package com.dbs.gamification;

        import android.content.Context;
        import android.content.Intent;
        import android.support.v7.app.AppCompatActivity;
        import android.os.Bundle;
        import android.view.View;
        import android.widget.Toast;

public class UserHome extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        CommonUtility.disableTitlebar(this);
        setContentView(R.layout.activity_user_home);
    }

    public void arrangeMe(View view) {
        Context context = getApplicationContext();
        CharSequence text = "number puzzle should load!";
        int duration = Toast.LENGTH_SHORT;

        Toast toast = Toast.makeText(context, text, duration);
        //toast.show();

        Intent intent = new Intent(this, GameActivity.class);
        startActivity(intent);
    }

    public void trivia(View view) {
        Context context = getApplicationContext();
        CharSequence text = "trivia puzzle should load!";
        int duration = Toast.LENGTH_SHORT;

        Toast toast = Toast.makeText(context, text, duration);
        //toast.show();

        Intent intent = new Intent(this, Trivia.class);
        startActivity(intent);
    }
}
